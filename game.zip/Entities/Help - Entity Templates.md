See the `/Templates/Entities/` folder for common sets of entities+components like players, monsters, collectibles etc.
